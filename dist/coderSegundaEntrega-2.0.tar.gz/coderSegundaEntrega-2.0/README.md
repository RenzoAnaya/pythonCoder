# pythonCoder

Segunda Entrega:

Crear un programa que permita el modelamiento de Clientes en una página de compras. Se debe utilizar el concepto de POO.

Se evaluará el uso correcto de atributos y métodos 

Utilizar los conceptos aprendidos enla clase 15 y crear un paquete redistribuible con el programa creado

Cliente:
4 atributos y 2 métodos
Debe crearse el método __str__() para nombrear los objetos
Para crear el paquete distribuible también como adicional el archivo de la Pre entrega #1
Es opcional el uso de herencia