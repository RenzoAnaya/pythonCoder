from setuptools import setup

setup(
    name="coderSegundaEntrega",
    version="2.0",
    description="Un paquete que servirá para modelar clientes en una página de compras y gestionar usuarios.",
    author="RenzoAnaya",
    author_email="r.anayaamaya@gmail.com",
    packages=["paquete"],
    classifiers=[
        "Programming Language :: Python :: 3",
    ],
)