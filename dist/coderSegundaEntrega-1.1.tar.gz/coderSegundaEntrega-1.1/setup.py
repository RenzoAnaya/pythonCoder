from setuptools import setup

setup(
    name="coderSegundaEntrega",
    version="1.1",
    description="Un paquete que servirá para modelar clientes en una página de compras y gestionar usuarios.",
    author="RenzoAnaya",
    author_email="r.anayaamaya@gmail.com",
    packages=["paquete"],
    classifiers=[
        "Programming Language :: Python :: 3",
    ],
)